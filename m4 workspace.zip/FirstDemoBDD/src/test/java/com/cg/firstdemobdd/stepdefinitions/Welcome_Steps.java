package com.cg.firstdemobdd.stepdefinitions;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Welcome_Steps {

	@Given("^User is on log in page$")
	public void user_is_on_log_in_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enters Akhil and Pass(\\d+)$")
	public void user_enters_Akhil_and_Pass(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Display  Hi Akhil$")
	public void display_Hi_Akhil() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enters Raj and Pass(\\d+)$")
	public void user_enters_Raj_and_Pass(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Display  Hello Raj$")
	public void display_Hello_Raj() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

}
