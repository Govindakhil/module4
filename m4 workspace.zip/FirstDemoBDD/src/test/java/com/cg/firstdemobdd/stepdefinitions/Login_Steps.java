package com.cg.firstdemobdd.stepdefinitions;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Login_Steps {

	@Given("^User is on LogIn Page$")
	public void user_is_on_LogIn_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User enters Akhil and pass(\\d+)$")
	public void user_enters_Akhil_and_pass(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Display Hi Akhil$")
	public void display_Hi_Akhil() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User enters Raj and pass(\\d+)$")
	public void user_enters_Raj_and_pass(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Display Hello Raj$")
	public void display_Hello_Raj() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	
}
