package com.cg.firstdemobdd.runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin= {"pretty"},
features = "src/test/resources/Tags"
,glue={"src/test/java/com/cg/firstdemobdd/stepdefinitions"}
,//tags= {"@SmokeTest"}
//tags= {"@RegressionTest"}
//tags= {"@End2End"}
tags= {"@FunctionalTest"}
)
public class Test_Runner {

}
