package com.cg.firstdemobdd.stepdefinitions;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;

public class Tags_Steps {

	@Given("^This is a blank test$")
	public void this_is_a_blank_test() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

}
