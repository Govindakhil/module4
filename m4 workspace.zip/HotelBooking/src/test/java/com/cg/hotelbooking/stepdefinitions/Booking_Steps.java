package com.cg.hotelbooking.stepdefinitions;

public class Booking_Steps {

}
